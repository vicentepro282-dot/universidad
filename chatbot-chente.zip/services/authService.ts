// This service uses localStorage to simulate a simple user database and session management.
// NOTE: This is for demonstration purposes only. For a real application,
// never store plain text passwords. Use a secure backend with password hashing.

const USERS_KEY = 'gemini_chat_users';
const ACTIVE_USER_KEY = 'gemini_chat_active_user';

interface User {
  username: string;
  password: string; // In a real app, this would be a hashed password.
}

const getUsers = (): User[] => {
  const usersJson = localStorage.getItem(USERS_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};

const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const register = (username: string, password: string): { success: boolean; message: string } => {
  const users = getUsers();
  const existingUser = users.find(user => user.username.toLowerCase() === username.toLowerCase());

  if (existingUser) {
    return { success: false, message: 'El nombre de usuario ya existe.' };
  }

  const newUser: User = { username, password };
  users.push(newUser);
  saveUsers(users);

  return { success: true, message: 'Usuario registrado con éxito.' };
};


export const login = (username: string, password: string): { success: boolean; message: string } => {
  const users = getUsers();
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

  if (!user) {
    return { success: false, message: 'Usuario no encontrado.' };
  }

  if (user.password !== password) {
    return { success: false, message: 'Contraseña incorrecta.' };
  }

  // Use localStorage to keep the user logged in across sessions
  localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify({ username: user.username }));

  return { success: true, message: 'Inicio de sesión exitoso.' };
};

export const logout = (): void => {
  localStorage.removeItem(ACTIVE_USER_KEY);
};

export const getCurrentUser = (): string | null => {
  const activeUserJson = localStorage.getItem(ACTIVE_USER_KEY);
  if (!activeUserJson) {
    return null;
  }
  const session = JSON.parse(activeUserJson);
  return session.username || null;
};