import { GoogleGenAI, Chat } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = "gemini-2.5-flash";

export const startChat = (): Chat => {
  return ai.chats.create({
    model,
    config: {
      systemInstruction: "Eres un chatbot servicial y amigable. Tus respuestas deben estar formateadas en markdown.",
    },
  });
};