import React, { useState, useRef, useEffect, useCallback } from 'react';
import { type Chat } from "@google/genai";
import { type Message, MessageRole } from '../types';
import { startChat } from '../services/geminiService';
import MessageList from './MessageList';
import MessageInput from './MessageInput';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const chatRef = useRef<Chat | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = startChat();
    setMessages([
        {
            id: 'initial-message',
            role: MessageRole.MODEL,
            content: "¡Hola! ¿Cómo puedo ayudarte hoy? Siéntete libre de preguntarme lo que sea."
        }
    ]);
  }, []);
  
  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading || !chatRef.current) return;
  
    const userMessage: Message = {
      id: Date.now().toString(),
      role: MessageRole.USER,
      content: input,
    };
  
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
  
    try {
      const stream = await chatRef.current.sendMessageStream({ message: input });
      
      let modelResponse = '';
      const modelMessageId = Date.now().toString() + '-model';
      let messageAdded = false;
      
      for await (const chunk of stream) {
        modelResponse += chunk.text;
        if (!messageAdded) {
          setMessages(prev => [...prev, { id: modelMessageId, role: MessageRole.MODEL, content: modelResponse }]);
          messageAdded = true;
        } else {
          setMessages(prev =>
            prev.map(msg =>
              msg.id === modelMessageId ? { ...msg, content: modelResponse } : msg
            )
          );
        }
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        id: Date.now().toString() + '-error',
        role: MessageRole.MODEL,
        content: "Lo siento, encontré un error. Por favor, inténtalo de nuevo.",
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading]);

  return (
    <div className="flex flex-col h-full bg-gray-800/30 rounded-lg mx-auto max-w-4xl shadow-2xl border border-gray-700/50">
      <MessageList messages={messages} scrollRef={scrollRef} isLoading={isLoading} />
      <MessageInput 
        input={input}
        setInput={setInput}
        onSendMessage={handleSendMessage}
        isLoading={isLoading}
      />
    </div>
  );
};

export default ChatInterface;