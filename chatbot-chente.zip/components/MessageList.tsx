import React from 'react';
import { type Message } from '../types';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

interface MessageListProps {
  messages: Message[];
  scrollRef: React.RefObject<HTMLDivElement>;
  isLoading: boolean;
}

const MessageList: React.FC<MessageListProps> = ({ messages, scrollRef, isLoading }) => {
  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
      {messages.map((message) => (
        <MessageBubble key={message.id} message={message} />
      ))}
      {isLoading && <TypingIndicator />}
    </div>
  );
};

export default MessageList;