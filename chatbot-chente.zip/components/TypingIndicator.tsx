import React from 'react';
import { BotIcon } from './icons/BotIcon';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-start gap-3 justify-start animate-slide-in-left">
      <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center order-1 bg-teal-500">
        <BotIcon className="w-5 h-5 text-white" />
      </div>
      <div className="max-w-xl p-4 rounded-xl shadow-md bg-gray-700/60 rounded-bl-none order-2">
        <div className="typing-indicator flex items-center justify-center space-x-1 h-5">
          <span className="typing-dot h-2 w-2 bg-gray-400 rounded-full"></span>
          <span className="typing-dot h-2 w-2 bg-gray-400 rounded-full"></span>
          <span className="typing-dot h-2 w-2 bg-gray-400 rounded-full"></span>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;