import React, { useState } from 'react';
import * as authService from '../services/authService';

interface LoginPageProps {
  onLoginSuccess: (username: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!username.trim() || !password.trim()) {
      setError('El nombre de usuario y la contraseña son obligatorios.');
      return;
    }
    
    try {
      if (isLoginMode) {
        const result = authService.login(username, password);
        if (result.success) {
          onLoginSuccess(username);
        } else {
          setError(result.message);
        }
      } else {
        const result = authService.register(username, password);
        if (result.success) {
            setSuccess('¡Registro exitoso! Por favor, inicia sesión.');
            setIsLoginMode(true);
            setUsername('');
            setPassword('');
        } else {
            setError(result.message);
        }
      }
    } catch (err) {
      setError('Ocurrió un error inesperado. Por favor, inténtalo de nuevo.');
    }
  };
  
  const toggleMode = () => {
    setIsLoginMode(!isLoginMode);
    setError(null);
    setSuccess(null);
    setUsername('');
    setPassword('');
  };

  return (
    <div className="flex items-center justify-center h-full">
      <div className="w-full max-w-md p-8 space-y-6 bg-gray-800/50 rounded-lg shadow-xl border border-gray-700/50">
        <h2 className="text-3xl font-bold text-center text-white">
          {isLoginMode ? 'Iniciar Sesión' : 'Crear Cuenta'}
        </h2>
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label
              htmlFor="username"
              className="text-sm font-medium text-gray-300 block mb-2"
            >
              Nombre de usuario
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label
              htmlFor="password"
              className="text-sm font-medium text-gray-300 block mb-2"
            >
              Contraseña
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          {error && <p className="text-sm text-red-400 text-center">{error}</p>}
          {success && <p className="text-sm text-green-400 text-center">{success}</p>}
          <button
            type="submit"
            className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 rounded-md text-white font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500"
          >
            {isLoginMode ? 'Entrar' : 'Registrarse'}
          </button>
        </form>
        <p className="text-sm text-center text-gray-400">
          {isLoginMode ? '¿No tienes una cuenta?' : '¿Ya tienes una cuenta?'}
          <button
            onClick={toggleMode}
            className="font-medium text-blue-400 hover:underline ml-1"
          >
            {isLoginMode ? 'Regístrate' : 'Inicia sesión'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
