import React, { useEffect, useState, useRef } from 'react';
import { type Message, MessageRole } from '../types';
import { UserIcon } from './icons/UserIcon';
import { BotIcon } from './icons/BotIcon';

// These are global functions from the CDN scripts in index.html
declare const marked: any;
declare const hljs: any;

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const [parsedContent, setParsedContent] = useState('');
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof marked !== 'undefined' && message.role === MessageRole.MODEL) {
      if (typeof hljs !== 'undefined') {
        // Configure marked to use highlight.js for syntax highlighting
        marked.setOptions({
          highlight: (code: string, lang: string) => {
            const language = hljs.getLanguage(lang) ? lang : 'plaintext';
            return hljs.highlight(code, { language }).value;
          },
          langPrefix: 'hljs language-', // Add language classes for highlight.js
        });
      }
      setParsedContent(marked.parse(message.content));
    } else {
        setParsedContent(message.content.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
  }, [message.content, message.role]);

  useEffect(() => {
    if (!contentRef.current) return;

    const preElements = contentRef.current.querySelectorAll('pre');
    
    preElements.forEach(pre => {
      if (pre.querySelector('.copy-button')) return;

      const code = pre.querySelector('code');
      if (!code) return;

      const button = document.createElement('button');
      button.className = 'copy-button absolute top-2 right-2 p-1.5 bg-gray-800/80 rounded-lg hover:bg-gray-700/80 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-blue-500';
      button.ariaLabel = 'Copiar código';
      
      const copyIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-300"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`;
      const checkIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-400"><path d="M20 6 9 17l-5-5"/></svg>`;

      button.innerHTML = copyIcon;
      
      button.onclick = () => {
        navigator.clipboard.writeText(code.innerText).then(() => {
          button.innerHTML = checkIcon;
          setTimeout(() => {
            button.innerHTML = copyIcon;
          }, 2000);
        });
      };

      pre.appendChild(button);
    });

  }, [parsedContent]);

  const isUser = message.role === MessageRole.USER;

  const bubbleClasses = isUser
    ? 'bg-blue-600/50 rounded-br-none'
    : 'bg-gray-700/60 rounded-bl-none';
  const flexClasses = isUser ? 'justify-end' : 'justify-start';

  const Icon = isUser ? UserIcon : BotIcon;
  const iconContainerClasses = isUser
    ? 'ml-3 order-2 bg-blue-500'
    : 'mr-3 order-1 bg-teal-500';
  
  const animationClass = isUser ? 'animate-slide-in-right' : 'animate-slide-in-left';

  return (
    <div className={`flex items-start gap-3 ${flexClasses} ${animationClass}`}>
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${iconContainerClasses} ${isUser ? '' : 'order-1'}`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className={`max-w-xl p-4 rounded-xl shadow-md ${bubbleClasses} ${isUser ? 'order-1' : 'order-2'}`}>
        <div 
          ref={contentRef}
          className="prose prose-invert prose-sm max-w-none prose-p:my-2 prose-headings:my-2" 
          dangerouslySetInnerHTML={{ __html: parsedContent }} 
        />
      </div>
    </div>
  );
};

export default MessageBubble;