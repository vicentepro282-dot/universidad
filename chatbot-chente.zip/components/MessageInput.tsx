import React from 'react';
import { SendIcon } from './icons/SendIcon';

interface MessageInputProps {
  input: string;
  setInput: (value: string) => void;
  onSendMessage: (e: React.FormEvent) => void;
  isLoading: boolean;
}

const MessageInput: React.FC<MessageInputProps> = ({ input, setInput, onSendMessage, isLoading }) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage(e as unknown as React.FormEvent);
    }
  };

  return (
    <div className="p-4 bg-gray-900/50 border-t border-gray-700">
      <form onSubmit={onSendMessage} className="relative flex items-center">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isLoading ? "Esperando respuesta..." : "Escribe tu mensaje..."}
          className="w-full bg-gray-800 border border-gray-600 rounded-lg py-3 pr-16 pl-4 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-shadow text-gray-200"
          rows={1}
          disabled={isLoading}
          style={{ maxHeight: '120px' }}
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-blue-600 text-white disabled:bg-gray-600 disabled:cursor-not-allowed hover:bg-blue-500 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500"
          aria-label="Enviar mensaje"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-transparent border-t-white rounded-full animate-spin"></div>
          ) : (
            <SendIcon className="w-5 h-5" />
          )}
        </button>
      </form>
    </div>
  );
};

export default MessageInput;